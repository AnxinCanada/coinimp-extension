if (localStorage.getItem("COINIMP") != null) {document.getElementById("COINIMP").value = localStorage.getItem("COINIMP")}
function update() {localStorage.setItem("COINIMP", document.getElementById("COINIMP").value)}
setInterval(update, 250)